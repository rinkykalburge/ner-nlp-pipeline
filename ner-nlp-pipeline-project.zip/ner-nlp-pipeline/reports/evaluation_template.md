# Evaluation Report Template

> Fill this report only after running the model on a labelled held-out test set. Do not invent metrics.

- Dataset and version:
- Licence / source:
- Language and domain:
- Number of documents:
- Number of gold entities:
- Train/validation/test split strategy:
- Model checkpoint and version:
- Entity label mapping:
- Preprocessing version:
- Precision:
- Recall:
- F1-score:
- Per-label metrics:
- Latency hardware and batch size:
- Main false-positive patterns:
- Main false-negative patterns:
- Known limitations:
