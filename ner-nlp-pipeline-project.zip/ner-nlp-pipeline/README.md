# NER Studio — Advanced Named Entity Recognition Pipeline

An educational NLP project that demonstrates an end-to-end NER workflow: text ingestion, model inference, entity highlighting, offset validation, model comparison, entity statistics, CSV/JSON export, evaluation helpers, and automated tests.

## Features

- Interactive Streamlit UI.
- spaCy pretrained NER baseline.
- Optional Hugging Face transformer NER model.
- Entity highlighting in the original text.
- Entity table with labels, offsets, model source, and confidence when supported.
- Honest confidence handling: standard spaCy NER does not expose calibrated per-entity confidence, so the app shows `None` rather than fabricated scores.
- Compare predictions between two models; agreement is not treated as ground truth.
- TXT, PDF, DOCX, and CSV text extraction.
- Entity counts and interactive charts.
- CSV and JSON export.
- Span-offset validation and error messages.
- Entity-level precision, recall, F1, and per-label evaluation helper.
- Unit tests and an evaluation-report template.

## Tech stack

Python, Streamlit, spaCy, Hugging Face Transformers, PyTorch, pandas, Plotly, pypdf, python-docx, pytest.

## Setup

Python 3.10+ is recommended.

```bash
python -m venv .venv
```

Windows PowerShell:
```powershell
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m spacy download en_core_web_sm
```

macOS/Linux:
```bash
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m spacy download en_core_web_sm
```

## Run the app

From the project root:

```bash
streamlit run app.py
```

The transformer model is optional and may download model weights on first use. If internet access or memory is unavailable, use the spaCy baseline.

## Run tests

```bash
pytest -q
```

## How to use

1. Enter text or upload TXT, PDF, DOCX, or CSV.
2. Select the primary NER model in the sidebar.
3. Enable model comparison if you want to compare spaCy with the transformer model.
4. Click **Analyze text**.
5. Review highlighted spans, entity labels, counts, offsets, charts, and latency.
6. Download extracted entities as CSV or the complete result as JSON.

## Example input

`Sundar Pichai is the CEO of Google. Google announced a new AI research centre in Bengaluru.`

Outputs vary by model. Always inspect the entity table and confirm important results.

## Evaluation

Use `src/evaluation.py` to calculate strict span-and-label precision, recall, F1, and per-label metrics from manually annotated gold spans and predictions. Meaningful metrics require labelled reference data. The app does not claim to calculate real model accuracy from unlabelled text.

See `reports/evaluation_template.md` for a reproducible report format.

## Suggested repository structure

```text
ner-nlp-pipeline/
├── app.py
├── requirements.txt
├── README.md
├── configs/
├── data/sample/
├── src/
├── tests/
└── reports/
```

## Limitations and responsible use

- This is an educational prototype, not a production service.
- Pretrained models may miss entities, mislabel ambiguous words, or perform poorly on domain-specific, multilingual, code-mixed, or noisy text.
- Confidence scores are model-dependent and are not necessarily calibrated probabilities.
- Entity-linking and relation extraction are future extensions, not currently implemented.
- Review model and dataset licences and terms before reuse.
- Do not use predictions as the sole basis for high-impact decisions.
- PDF extraction quality depends on whether the PDF contains extractable text; scanned PDFs require OCR, which is not included here.
- Large transformer models may require more memory and an internet connection for the first download.

## GitHub submission

Create a repository named `ner-nlp-pipeline`, upload the files, verify that setup and tests work on your machine, and submit the actual repository URL. The suggested URL `https://github.com/rinkykalburge/ner-nlp-pipeline` is only a proposal until you create it.

## Future improvements

- Fine-tune a transformer on a licensed, manually labelled target-domain dataset.
- Add annotation tools and an active-learning queue.
- Add OCR for scanned PDFs.
- Add multilingual routing and domain-specific label sets.
- Add relation extraction and entity linking.
- Add FastAPI deployment, authentication, model version registry, monitoring, and drift alerts.
