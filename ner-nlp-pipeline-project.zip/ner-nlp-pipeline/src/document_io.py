"""Text extraction from TXT, PDF, DOCX and CSV files."""
from pathlib import Path
import csv
from io import StringIO

def extract_text(filename: str, data: bytes) -> str:
    suffix = Path(filename).suffix.lower()
    if suffix == ".txt":
        return data.decode("utf-8", errors="replace")
    if suffix == ".pdf":
        from pypdf import PdfReader
        from io import BytesIO
        reader = PdfReader(BytesIO(data))
        return "\n\n".join(page.extract_text() or "" for page in reader.pages)
    if suffix == ".docx":
        from docx import Document
        from io import BytesIO
        doc = Document(BytesIO(data))
        paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
        for table in doc.tables:
            for row in table.rows:
                paragraphs.append(" | ".join(cell.text for cell in row.cells))
        return "\n".join(paragraphs)
    if suffix == ".csv":
        content = data.decode("utf-8", errors="replace")
        rows = csv.reader(StringIO(content))
        return "\n".join(" | ".join(cell for cell in row) for row in rows)
    raise ValueError("Unsupported file type. Use TXT, PDF, DOCX, or CSV.")
