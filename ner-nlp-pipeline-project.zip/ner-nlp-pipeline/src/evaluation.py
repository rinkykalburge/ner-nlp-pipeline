"""Entity-level evaluation helpers. Requires manually labelled gold spans or token tags."""
from collections import defaultdict

def span_metrics(gold: list[dict], predicted: list[dict]) -> dict:
    """Strict span/type match. Records require text, label, start, end."""
    key = lambda e: (e["label"], int(e["start"]), int(e["end"]), e.get("text", ""))
    g, p = {key(e) for e in gold}, {key(e) for e in predicted}
    tp, fp, fn = len(g & p), len(p - g), len(g - p)
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2*precision*recall/(precision+recall) if precision+recall else 0.0
    labels = sorted({e["label"] for e in gold} | {e["label"] for e in predicted})
    per_label = {}
    for label in labels:
        gl = {x for x in g if x[0] == label}
        pl = {x for x in p if x[0] == label}
        ltp, lfp, lfn = len(gl & pl), len(pl - gl), len(gl - pl)
        lp = ltp/(ltp+lfp) if ltp+lfp else 0.0
        lr = ltp/(ltp+lfn) if ltp+lfn else 0.0
        per_label[label] = {"precision": lp, "recall": lr,
                            "f1": 2*lp*lr/(lp+lr) if lp+lr else 0.0,
                            "gold_count": len(gl), "predicted_count": len(pl)}
    return {"true_positive": tp, "false_positive": fp, "false_negative": fn,
            "precision": precision, "recall": recall, "f1": f1, "per_label": per_label,
            "warning": "Meaningful evaluation requires correctly labelled gold annotations."}
