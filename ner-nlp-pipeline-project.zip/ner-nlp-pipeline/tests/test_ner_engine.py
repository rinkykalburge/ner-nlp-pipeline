from src.ner_engine import validate_entities, compare_results
from src.evaluation import span_metrics

def test_validate_entity_offsets():
    text = "Riya joined Infosys."
    entities = [{"text": "Riya", "label": "PERSON", "start": 0, "end": 4},
                {"text": "bad", "label": "ORG", "start": 100, "end": 103}]
    valid, warnings = validate_entities(text, entities)
    assert len(valid) == 1
    assert valid[0]["text"] == "Riya"
    assert warnings

def test_span_metrics_perfect():
    gold = [{"text":"Riya","label":"PERSON","start":0,"end":4}]
    result = span_metrics(gold, gold)
    assert result["precision"] == 1.0
    assert result["recall"] == 1.0
    assert result["f1"] == 1.0

def test_compare_models():
    a = {"entities":[{"text":"Riya","label":"PERSON","start":0,"end":4}]}
    b = {"entities":[{"text":"Riya","label":"PERSON","start":0,"end":4},
                     {"text":"Infosys","label":"ORG","start":12,"end":19}]}
    result = compare_results(a,b)
    assert len(result["shared"]) == 1
    assert len(result["only_model_b"]) == 1
