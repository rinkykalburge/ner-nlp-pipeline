"""NER engine with spaCy baseline and optional Hugging Face transformer support."""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any
import time

@dataclass
class Entity:
    text: str
    label: str
    start: int
    end: int
    confidence: float | None = None
    source_model: str = "unknown"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

def _spacy_confidence(ent) -> float | None:
    # spaCy's standard NER pipeline does not expose calibrated per-entity confidence.
    # Return None rather than inventing a score.
    return None

def extract_with_spacy(text: str, model_name: str = "en_core_web_sm") -> dict[str, Any]:
    """Run spaCy NER. Install the model separately: python -m spacy download en_core_web_sm."""
    if not isinstance(text, str) or not text.strip():
        return {"status": "invalid_input", "entities": [], "warnings": ["Please enter non-empty text."],
                "model": model_name, "latency_ms": 0.0}
    start = time.perf_counter()
    try:
        import spacy
        nlp = spacy.load(model_name)
        doc = nlp(text)
        entities = [
            Entity(ent.text, ent.label_, ent.start_char, ent.end_char, _spacy_confidence(ent), model_name).to_dict()
            for ent in doc.ents
        ]
        return {"status": "success", "entities": entities, "warnings": [],
                "model": model_name, "latency_ms": round((time.perf_counter()-start)*1000, 2)}
    except OSError:
        return {"status": "model_unavailable", "entities": [],
                "warnings": [f"spaCy model '{model_name}' is not installed. Run: python -m spacy download {model_name}"],
                "model": model_name, "latency_ms": round((time.perf_counter()-start)*1000, 2)}
    except Exception as exc:
        return {"status": "processing_error", "entities": [],
                "warnings": [f"NER processing failed ({type(exc).__name__}). Check the logs and input."],
                "model": model_name, "latency_ms": round((time.perf_counter()-start)*1000, 2)}

def extract_with_transformer(text: str, model_name: str = "dslim/bert-base-NER") -> dict[str, Any]:
    """Optional transformer pipeline. Downloads model weights on first use; internet may be required."""
    if not isinstance(text, str) or not text.strip():
        return {"status": "invalid_input", "entities": [], "warnings": ["Please enter non-empty text."],
                "model": model_name, "latency_ms": 0.0}
    start = time.perf_counter()
    try:
        from transformers import pipeline
        ner = pipeline("token-classification", model=model_name, aggregation_strategy="simple")
        predictions = ner(text)
        entities = []
        for item in predictions:
            s, e = int(item["start"]), int(item["end"])
            if 0 <= s < e <= len(text) and text[s:e] == item.get("word", text[s:e]):
                surface = text[s:e]
            else:
                surface = text[s:e] if 0 <= s < e <= len(text) else str(item.get("word", ""))
            entities.append(Entity(
                text=surface, label=str(item.get("entity_group", item.get("entity", "UNKNOWN"))),
                start=s, end=e,
                confidence=round(float(item["score"]), 4) if item.get("score") is not None else None,
                source_model=model_name
            ).to_dict())
        return {"status": "success", "entities": entities, "warnings": [],
                "model": model_name, "latency_ms": round((time.perf_counter()-start)*1000, 2)}
    except Exception as exc:
        return {"status": "processing_error", "entities": [],
                "warnings": [f"Transformer inference failed ({type(exc).__name__}). The model may need internet access or more memory."],
                "model": model_name, "latency_ms": round((time.perf_counter()-start)*1000, 2)}

def validate_entities(text: str, entities: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[str]]:
    """Validate offsets and surface text; invalid predictions are excluded with a warning."""
    valid, warnings = [], []
    for ent in entities:
        try:
            s, e = int(ent["start"]), int(ent["end"])
            if not (0 <= s < e <= len(text)):
                warnings.append(f"Rejected out-of-range span: {ent.get('text', '')!r}")
                continue
            actual = text[s:e]
            if actual != ent.get("text"):
                ent = {**ent, "text": actual}
                warnings.append("Corrected entity surface text from original character offsets.")
            valid.append(ent)
        except (KeyError, TypeError, ValueError):
            warnings.append("Rejected malformed entity record.")
    return valid, warnings

def compare_results(a: dict[str, Any], b: dict[str, Any]) -> dict[str, Any]:
    """Compare model spans by (text, label, start, end), without implying either is ground truth."""
    key = lambda e: (e["text"], e["label"], e["start"], e["end"])
    aset, bset = {key(e) for e in a.get("entities", [])}, {key(e) for e in b.get("entities", [])}
    return {
        "shared": [dict(text=t, label=l, start=s, end=e) for t,l,s,e in sorted(aset & bset)],
        "only_model_a": [dict(text=t, label=l, start=s, end=e) for t,l,s,e in sorted(aset - bset)],
        "only_model_b": [dict(text=t, label=l, start=s, end=e) for t,l,s,e in sorted(bset - aset)],
        "note": "Agreement is not proof of correctness; validate against labelled reference data."
    }
