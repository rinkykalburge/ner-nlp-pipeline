from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
import plotly.express as px
import streamlit as st

from src.ner_engine import extract_with_spacy, extract_with_transformer, validate_entities, compare_results
from src.document_io import extract_text

st.set_page_config(page_title="NER Studio", page_icon="🔎", layout="wide")
st.title("🔎 NER Studio")
st.caption("Advanced Named Entity Recognition • interactive analysis • model comparison")
st.info("Predictions are model outputs, not guaranteed facts. Standard spaCy NER does not provide calibrated entity confidence scores.")

with st.sidebar:
    st.header("Settings")
    model_choice = st.selectbox("Primary model", ["spaCy baseline", "Transformer (BERT NER)"])
    enable_compare = st.checkbox("Compare both models", value=False)
    show_offsets = st.checkbox("Show character offsets", value=True)
    st.markdown("---")
    st.markdown("**Model setup**")
    st.code("python -m spacy download en_core_web_sm")
    st.caption("Transformer mode may download model weights on first run.")

default_text = ("Sundar Pichai is the CEO of Google. Google announced a new AI research centre "
                "in Bengaluru on 22 October 2026.")
text_input = st.text_area("Enter text to analyze", value=default_text, height=170)
uploaded = st.file_uploader("Or upload a document", type=["txt", "pdf", "docx", "csv"])
if uploaded:
    try:
        text_input = extract_text(uploaded.name, uploaded.getvalue())
        st.success(f"Loaded text from {uploaded.name} ({len(text_input):,} characters).")
        st.text_area("Extracted text preview", value=text_input[:10000], height=120, disabled=True)
        if len(text_input) > 10000:
            st.warning("Preview limited to 10,000 characters. The full extracted text will be analyzed.")
    except Exception as exc:
        st.error(f"Could not read file: {exc}")

def highlight_html(text, entities):
    import html
    items = sorted(entities, key=lambda e: (int(e["start"]), int(e["end"])))
    out, cursor = [], 0
    palette = {"PERSON":"#dbeafe", "PER":"#dbeafe", "ORG":"#dcfce7", "ORGANIZATION":"#dcfce7",
               "GPE":"#fef3c7", "LOC":"#fef3c7", "LOCATION":"#fef3c7", "DATE":"#fce7f3",
               "MONEY":"#ede9fe", "PRODUCT":"#cffafe", "EVENT":"#ffedd5"}
    for ent in items:
        s, e = int(ent["start"]), int(ent["end"])
        if s < cursor or s < 0 or e > len(text) or e <= s:
            continue
        out.append(html.escape(text[cursor:s]))
        color = palette.get(ent["label"].upper(), "#e5e7eb")
        label = html.escape(str(ent["label"]))
        surface = html.escape(text[s:e])
        out.append(f'<span style="background:{color};padding:2px 4px;border-radius:4px;border:1px solid #94a3b8" title="{label}">{surface}<sup> {label}</sup></span>')
        cursor = e
    out.append(html.escape(text[cursor:]))
    return "".join(out)

if st.button("Analyze text", type="primary", use_container_width=True):
    if not text_input.strip():
        st.error("Enter text or upload a document first.")
        st.stop()
    with st.spinner("Running NER..."):
        primary = extract_with_spacy(text_input) if model_choice == "spaCy baseline" else extract_with_transformer(text_input)
        primary["entities"], span_warnings = validate_entities(text_input, primary.get("entities", []))
    if primary["status"] != "success":
        for warning in primary.get("warnings", []):
            st.error(warning)
        st.stop()
    for warning in span_warnings:
        st.warning(warning)

    entities = primary["entities"]
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Entities detected", len(entities))
    c2.metric("Entity types", len(set(e["label"] for e in entities)))
    c3.metric("Characters", f"{len(text_input):,}")
    c4.metric("Latency", f"{primary['latency_ms']:.1f} ms")
    st.subheader("Highlighted text")
    st.markdown(highlight_html(text_input, entities), unsafe_allow_html=True)

    st.subheader("Extracted entities")
    if entities:
        df = pd.DataFrame(entities)
        columns = ["text", "label", "confidence", "start", "end", "source_model"]
        if not show_offsets:
            columns = ["text", "label", "confidence", "source_model"]
        available = [c for c in columns if c in df.columns]
        st.dataframe(df[available], use_container_width=True, hide_index=True)
        labels = df["label"].value_counts().rename_axis("Entity type").reset_index(name="Count")
        left, right = st.columns(2)
        with left:
            st.plotly_chart(px.bar(labels, x="Entity type", y="Count", title="Entities by type"), use_container_width=True)
        with right:
            st.plotly_chart(px.pie(labels, names="Entity type", values="Count", title="Entity distribution"), use_container_width=True)
        st.download_button("Download entities as CSV", df.to_csv(index=False).encode("utf-8"), "ner_entities.csv", "text/csv")
        json_payload = {"status": primary["status"], "model": primary["model"], "latency_ms": primary["latency_ms"], "entities": entities}
        st.download_button("Download results as JSON", json.dumps(json_payload, indent=2).encode("utf-8"), "ner_results.json", "application/json")
    else:
        st.info("No entities were detected. This does not necessarily mean the text contains no entities.")

    if enable_compare:
        st.subheader("Model comparison")
        with st.spinner("Running the second model..."):
            if model_choice == "spaCy baseline":
                second = extract_with_transformer(text_input)
            else:
                second = extract_with_spacy(text_input)
        if second["status"] != "success":
            st.warning("Second model unavailable: " + "; ".join(second.get("warnings", [])))
        else:
            comparison = compare_results(primary, second)
            a,b,c = st.columns(3)
            a.metric("Shared predictions", len(comparison["shared"]))
            b.metric("Only primary model", len(comparison["only_model_a"]))
            c.metric("Only second model", len(comparison["only_model_b"]))
            st.caption(comparison["note"])
            st.json(comparison)

st.markdown("---")
st.caption("NER Studio • Prototype for educational use. Review model licences and validate results on labelled data before real-world use.")
